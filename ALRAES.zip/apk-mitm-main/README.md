
# ALRAES APK MITM

> A CLI application that automatically prepares Android APK files for HTTPS inspection.

**Developer:** الرئيس  
**Telegram:** @id11tt  
**Channel:** https://t.me/tt6_7tt

---

## About

ALRAES APK MITM is a command-line application for preparing Android APK files for HTTPS inspection in authorized testing environments.

The project is based on the original apk-mitm project.

## Features

- APK file analysis.
- Network security configuration inspection.
- APK processing for authorized HTTPS testing.
- APK rebuilding and signing.

## Installation

Requirements:

- Node.js 14+
- Java 8+

Install dependencies:

```bash
npm install
```

Build:

```bash
npm run build
```

## Usage

```bash
alraes-apk-mitm <path-to-apk>
```

## Developer

**Name:** الرئيس

**Username:** @id11tt

**Telegram Channel:** https://t.me/tt6_7tt

## Credits

Original project: apk-mitm

Original developer: Niklas Higi

This project retains the original MIT license and attribution.

## License

MIT License.

See the LICENSE file for full license terms.
